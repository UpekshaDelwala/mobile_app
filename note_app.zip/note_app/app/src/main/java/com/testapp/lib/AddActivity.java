package com.testapp.lib;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class AddActivity extends AppCompatActivity {

    private TextView titleView;
    EditText mainText ,subTexttwo;
    private Button addBtn;
    private DBHandler dbHandler;
    private String mode;

    private String desc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        dbHandler = new DBHandler(AddActivity.this);

        long currentTimeMillis = System.currentTimeMillis();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        String formattedTimestamp = sdf.format(new Date(currentTimeMillis));

        mode = getIntent().getStringExtra("mode");

        titleView = findViewById(R.id.title_text);
        mainText = findViewById(R.id.sub_text);
        subTexttwo = findViewById(R.id.sub_text_3);

        addBtn = findViewById(R.id.insert_btn);

        if (mode.equals("book")){
            titleView.setText("Write your note here...");
            mainText.setHint("Title");
            //subText.setHint("Date");
            subTexttwo.setHint("Description");

            addBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    addBookRecord(mainText.getText().toString(),  subTexttwo.getText().toString());
                }
            });

        }

        else if (mode.equals("updatebook")){

            String note_id = getIntent().getStringExtra("id");
            String title = getIntent().getStringExtra("title");
            String desc = getIntent().getStringExtra("desc");

            titleView.setText("Update a Note");

            mainText.setHint("Title");
            subTexttwo.setHint("Description");

            mainText.setText(title);
            subTexttwo.setText(desc);

            addBtn.setText("UPDATE NOTE");

            addBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    updateBookRecord(note_id, mainText.getText().toString(), subTexttwo.getText().toString());
                }
            });

        }


    }

    private void updateBookRecord(String bookId, String title, String desc) {


        if (!title.isEmpty() || !desc.isEmpty()){
            DBHandler dbHandler = new DBHandler(this);
            SQLiteDatabase db = dbHandler.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("title", title);
            values.put("description", desc);

            String selection = "rec_id = ?";
            String[] selectionArgs = {bookId};

            int rowsAffected = db.update("records", values, selection, selectionArgs);

            if (rowsAffected > 0) {
                Toast.makeText(this, "Data updated!", Toast.LENGTH_SHORT).show();
                finish();

            } else {
                Toast.makeText(this, "Error!", Toast.LENGTH_SHORT).show();
            }
            db.close();

        }else {
            Toast.makeText(AddActivity.this, "Empty fields", Toast.LENGTH_LONG).show();
        }

    }

    private void addBookRecord(String title, String desc) {

        if (!title.isEmpty() || !desc.isEmpty()){
            dbHandler.addRecord(title,desc);
            mainText.setText("");
            //subText.setText("");
            subTexttwo.setText("");
            Toast.makeText(AddActivity.this, "Note added!", Toast.LENGTH_LONG).show();

        }else {
            Toast.makeText(AddActivity.this, "Empty fields", Toast.LENGTH_LONG).show();
        }

    }
}