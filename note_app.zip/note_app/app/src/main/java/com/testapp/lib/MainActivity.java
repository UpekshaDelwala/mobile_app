package com.testapp.lib;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private DBHandler dbHandler;
    private RecyclerView noteContainer;
    private List<Note> noteList;
    private NoteAdapter noteAdapter;

    private Button addBook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHandler = new DBHandler(MainActivity.this);
        if (isRecordsTableEmpty()){
            addFirstRecs();
            Toast.makeText(MainActivity.this,"Loading initial records...", Toast.LENGTH_LONG).show();
        }
        loadBooks();
        //11__loadUsers();

        addBook = findViewById(R.id.insert_btn);
        //7__addMem = findViewById(R.id.user_insert_btn);

        addBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddActivity.class);
                intent.putExtra("mode", "book");
                startActivity(intent);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        loadBooks();
    }

    private void addFirstRecs() {

        long currentTimeMillis = System.currentTimeMillis();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        String formattedTimestamp = sdf.format(new Date(currentTimeMillis));

        dbHandler.addRecord("Quotes to Life", "The future belongs to those who believe in the beauty of their dreams. -Eleanor Roosevelt");
        dbHandler.addRecord("Grosery list","suger 1kg" +
                "astra 500g" +
                "3 eggs ");

    }

    private void loadBooks() {

        noteContainer = findViewById(R.id.note_container);
        dbHandler = new DBHandler(this);
        noteList = new ArrayList<>();
        noteAdapter = new NoteAdapter(noteList, this);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        noteContainer.setLayoutManager(layoutManager);
        noteContainer.setAdapter(noteAdapter);

        SQLiteDatabase db = dbHandler.getReadableDatabase();
        String[] projection = {"rec_id", "title", "description"};
        Cursor cursor = db.query("records", projection, null, null, null, null, "rec_id DESC");

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int rec_id = Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow("rec_id")));
                String id = String.valueOf(rec_id);
                String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
                //String author = cursor.getString(cursor.getColumnIndexOrThrow("author"));
                String desc = cursor.getString(cursor.getColumnIndexOrThrow("description"));

                Note book = new Note(id, title, desc);
                noteList.add(book);
            } while (cursor.moveToNext());

            cursor.close();
            noteAdapter.notifyDataSetChanged();
        }

        db.close();

    }



    public boolean isRecordsTableEmpty() {
        SQLiteDatabase db = dbHandler.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM records", null);
        if (cursor != null) {
            cursor.moveToFirst();
            int count = cursor.getInt(0);
            cursor.close();
            return count == 0;
        }
        return true; // Assume empty if cursor is null
    }


}