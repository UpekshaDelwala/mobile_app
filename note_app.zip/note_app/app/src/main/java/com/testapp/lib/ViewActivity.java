package com.testapp.lib;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ViewActivity extends AppCompatActivity {

    TextView tileText, descText;
    Button updateBtn,delBtn;
    DBHandler dbHandler;
    RecyclerView noteContainer;
    List<Note> noteList;
    NoteAdapter noteAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        String book_id = getIntent().getStringExtra("id");
        String title = getIntent().getStringExtra("title");
        String desc = getIntent().getStringExtra("desc");

        tileText = findViewById(R.id.book_title);
        descText = findViewById(R.id.book_desc);
        updateBtn = findViewById(R.id.update_btn);
        delBtn = findViewById(R.id.del_btn);

        loadnotes();

        tileText.setText(title);
        descText.setText(desc);

        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewActivity.this, AddActivity.class);
                intent.putExtra("mode", "updatebook");
                intent.putExtra("id", book_id);
                intent.putExtra("title", title);
                intent.putExtra("desc", desc);
                startActivity(intent);
            }
        });

        delBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(ViewActivity.this);
                builder.setMessage("You are going to delete this note!");
                builder.setTitle("   Delete note");
                builder.setCancelable(true);
                builder.setNegativeButton("No", (DialogInterface.OnClickListener) (dialog, which) -> {
                    dialog.cancel();
                });
                builder.setPositiveButton("Delete", (DialogInterface.OnClickListener) (dialog, which) -> {
                    deleteRecord(book_id, title, desc);

                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });

    }

    private void deleteRecord(String bookId, String title, String desc) {
        DBHandler dbHandler = new DBHandler(ViewActivity.this);
        SQLiteDatabase db = dbHandler.getWritableDatabase();

        String selection = "rec_id = ? AND title = ? AND description = ?";
        String[] selectionArgs = {bookId, title, desc};
        db.delete("records", selection, selectionArgs);

        db.close();
        Toast.makeText(ViewActivity.this,"Note deleted successfully!", Toast.LENGTH_LONG).show();
        finish();

    }

    @Override
    protected void onResume() {
        super.onResume();
        loadnotes();
    }

    private void loadnotes() {

        noteContainer = findViewById(R.id.note_container);
        dbHandler = new DBHandler(this);
        noteList = new ArrayList<>();
        NoteAdapter noteAdapter = new NoteAdapter(noteList, this);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        noteContainer.setLayoutManager(layoutManager);
        noteContainer.setAdapter(noteAdapter);

        SQLiteDatabase db = dbHandler.getReadableDatabase();
        String[] projection = {"rec_id", "title", "description"};
        Cursor cursor = db.query("records", projection, null, null, null, null, "rec_id DESC");

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int rec_id = Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow("rec_id")));
                String id = String.valueOf(rec_id);
                String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
                String desc = cursor.getString(cursor.getColumnIndexOrThrow("description"));

                Note note = new Note(id, title, desc);
                noteList.add(note);
            } while (cursor.moveToNext());

            cursor.close();
            noteAdapter.notifyDataSetChanged();
        }

        db.close();

    }
}